const express = require('express');
const multer = require('multer')
const fs = require('fs')
const path = require('path')

const app = express()
app.use(express.static('public'))
app.set('view engine','ejs')


const storage = multer.diskStorage({
    destination : function(req,fie,cb){
         cb(null, 'public/uploads')
    },
    filename: function(req,file,cb){
        cb(null,Date.now() + '_' + file.originalname)
    }
})

const upload = multer({storage : storage})

app.post('/upload', upload.single('file'),(req,res)=>{
     res.redirect('/')
})


app.get('/',(req,res)=>{
    const uploadDirectory = path.join(__dirname, 'public/uploads')
    fs.readdir(uploadDirectory,(err,files)=>{
        if(err){
            console.log(err);
            return res.status(500).send('interal server Error')
        }else{
             res.render('index', {files: files})
             
        }
    })
})


app.get('/download/:filename',(req,res)=>{
     const file = path.join(__dirname,'public/uploads',req.params.filename)
     res.download(file)
})


app.listen(5000,()=>{
    console.log("Server Is Runing");
})